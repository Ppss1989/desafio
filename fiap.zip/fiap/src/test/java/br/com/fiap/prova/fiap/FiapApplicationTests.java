package br.com.fiap.prova.fiap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiapApplicationTests {

	@Test
	void contextLoads() {
	}

}
